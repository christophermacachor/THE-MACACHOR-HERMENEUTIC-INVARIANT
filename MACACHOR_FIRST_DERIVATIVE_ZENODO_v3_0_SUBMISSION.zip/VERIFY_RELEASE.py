#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys

ROOT = Path(__file__).resolve().parent
required = [
    "MACACHOR_FIRST_DERIVATIVE_v3.0.md",
    "MACACHOR_FIRST_DERIVATIVE_v3.0.pdf",
    "README_HARDENED_v3.0.md",
    "CITATION_HARDENED_v3.0.cff",
    "zenodo_hardened_v3.0.json",
    "SHA256SUMS.txt",
]

for name in required:
    if not (ROOT/name).exists():
        print("FAIL missing:", name)
        sys.exit(1)

text = (ROOT/"MACACHOR_FIRST_DERIVATIVE_v3.0.md").read_text(encoding="utf-8")
for phrase in [
    "Macachor First Derivative",
    "maximum structure-preserving compression",
    "minimum sufficient structure",
    "Discovery",
    "Foundational Law",
    "Formalization",
    "Verification",
    "Macachor Absolute",
    "Quantization",
    "Falsifiability",
]:
    if phrase not in text:
        print("FAIL missing phrase:", phrase)
        sys.exit(1)

print("PASS: release structure verified.")
for name in required:
    digest = hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    print(digest, name)
