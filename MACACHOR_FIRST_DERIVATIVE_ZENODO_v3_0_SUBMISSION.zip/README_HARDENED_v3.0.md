# MACACHOR FIRST DERIVATIVE — v3.0 ZENODO SUBMISSION

Canonical hardened release.

## Files

- MACACHOR_FIRST_DERIVATIVE_v3.0.md
- MACACHOR_FIRST_DERIVATIVE_v3.0.pdf
- README_HARDENED_v3.0.md
- CITATION_HARDENED_v3.0.cff
- zenodo_hardened_v3.0.json
- VERIFY_RELEASE.py
- SHA256SUMS.txt

## Canonical sequence

Discovery → Foundational Law → Formalization → Quantization → Verification → Consequences

## Claim boundary

The First Derivative is presented as Christopher Macachor's foundational discovery and law. Mathematical formalization, AI experiments, quantum mappings, and physical consequences are separately classified and remain subject to verification.

## Zenodo metadata

The JSON file is a metadata draft. Before publication, confirm the final Zenodo record title, creator metadata, DOI/version relationship, publication date, license, and uploaded hashes against the actual Zenodo record.
